# Carga de librer�as
library(MASS)
library(robustbase)
library(dglm)
library(hnp)
library(ggplot2)
library(gmodels)
library(ResourceSelection)
library(Epi)
########################### Pregunta 1  

setwd("D:/Estadistica/maestr�a/Ciclo II/Modelos Lineales 2/Maehara/PC3")

data <-read.csv("supervivencia.csv", sep=",")
attach(data)
##str(data)
##table(data$AG)
data$AG=as.factor(AG)

### a- An�lisis descriptivo
ajuste0.superv = glm(Tiempo ~1, family=Gamma)
ajuste00.superv = glm(Tiempo ~1, family=inverse.gaussian)
summary(ajuste0.superv)
summary(ajuste00.superv) ## la dispersi�n de del ajuste de la normal inversa es 0.03193309

hist(Tiempo, prob=TRUE,xlab = "Tiempo",main = "Tiempo de supervivencia en semanas",ylab = "Prob", ylim = c(0,0.04))
curve(dgamma(x, rate=as.numeric(gamma.shape(ajuste0.superv)[1])/mean(Tiempo),
             shape=as.numeric(gamma.shape(ajuste0.superv)[1])),add = TRUE,col="darkblue", lwd=2)
curve(dinvgauss(x, mean=mean(Tiempo), shape=NULL, dispersion=0.03193309, log=FALSE), from= 0, to=160, add=TRUE, col="darkgreen", lwd=2)
#lines(density(Tiempo),col="darkgreen", lwd=2)

# La distribuci�n de los tiempos parecen ajustarse a una gamma (con cola a la derecha) o normal inversa. 
# Comparando gr�ficamente ls distribuci�n gamma (linea azul) parece ajustar mejor los datos de tiempo de tiempo de supervivencia en semanas.

## a- Evaluaci�n de modelos lineales Generalizados - MLG

# Gamma
ajuste1.superv = glm(Tiempo ~ AG + log(gblancos), family=Gamma) ## por default utiliza link=inverse
stepAIC(ajuste1.superv) ## ambas covariables ingresan al modelo
summary(ajuste1.superv)
AIC_MLG_Gamma.1=AIC(ajuste1.superv) ; AIC_MLG_Gamma.1

ajuste2.superv = glm(Tiempo ~ AG + log(gblancos), family=Gamma(link=log))
stepAIC(ajuste2.superv) ## ambas covariables ingresan al modelo
summary(ajuste2.superv)
AIC_MLG_Gamma.2=AIC(ajuste2.superv) ; AIC_MLG_Gamma.2

# Normal Inversa
ajuste3.superv = glm(Tiempo ~ AG + log(gblancos), family=inverse.gaussian(link=identity))
ajuste3.superv=stepAIC(ajuste1.superv)
summary(ajuste3.superv)
AIC_MLG_InvGauss=AIC(ajuste3.superv) ; AIC_MLG_InvGauss

#Graficas de ajuste de modelos
hnp(ajuste1.superv, halfnormal = FALSE)
hnp(ajuste2.superv, halfnormal = FALSE)
hnp(ajuste3.superv, halfnormal = FALSE)

### En los gr�ficos se observa que los datos est�n dentro de la banda de confianza
### pero no se ajustan a la media de la variable de respuesta por los modelos lineales generalizados gamma y normal inversa

### a- An�lisis de medias, desviacion estandar y coeficiente de variabilidad

adjbox(split(Tiempo, AG), ylab="Tiempo de supervivencia en semanas")   #Ajuste robusto para distribuciones asim�tricas

supervivencia.m<-tapply(X=Tiempo,INDEX=AG,FUN=mean)
supervivencia.sd<-tapply(X=Tiempo,INDEX=AG,FUN=sd)
supervivencia.cv<-supervivencia.sd/supervivencia.m*100
desc_superv<-rbind(supervivencia.m,supervivencia.sd,supervivencia.cv)
row.names(desc_superv)<-c("M�dia","SD","CV")
desc_superv

AG <- c(0,1)
f <- cbind(c(desc_superv[1,1],desc_superv[1,2]),c(desc_superv[3,1],desc_superv[3,2]))
matplot(AG,f,type="l", col=c("deepskyblue4", "firebrick1"), ylab
        ="unidades",xlab="AG",lwd=2,ylim = c(0,115))
legend("topright",c("Media del Tiempo, u= semanas", "CV del tiempo en semanas, u=%"),
       col = c("deepskyblue4", "firebrick1"), lty=1:2,lwd=2,
       seg.len=2,cex=0.8,box.lty=0,bg=NULL)

# Mediante el an�lisis descriptivo se observa diferencias en la media de tiempo de supervivencia en semanas respecto a los pacientres que presentan la caracter�stica morfol�gica de los que no la presentan
# Por otro lado, tambien  existen grandes diferencias en los coeficiente de variaci�n entre los grupos, lo cual podr�a sugerir el uso de un modelo doble generalizado. 

## a- Modelos dobles generalizados - DGLM

## Gamma

ajuste4.superv = dglm(Tiempo ~ factor(AG) + log(gblancos), ~ factor(AG), family=Gamma(link=log),data=data)
summary(ajuste4.superv)
AIC_DGLM_Gamma.1 <- ajuste4.superv$m2loglik+2*5 ; AIC_DGLM_Gamma.1

ajuste5.superv = dglm(Tiempo ~ factor(AG) + log(gblancos), ~ factor(AG) + log(gblancos), family=Gamma(link=log),data=data)
summary(ajuste5.superv)
AIC_DGLM_Gamma.2 <- ajuste5.superv$m2loglik+2*6 ; AIC_DGLM_Gamma.2

ajuste6.superv = dglm(Tiempo ~ factor(AG) + log(gblancos), ~ log(gblancos), family=Gamma(link=log),data=data)
summary(ajuste6.superv)
AIC_DGLM_Gamma.3 <- ajuste6.superv$m2loglik+2*5 ; AIC_DGLM_Gamma.3

## Gr�ficos de ajuste de DGLM
hnp(ajuste4.superv, halfnormal = FALSE)
hnp(ajuste5.superv, halfnormal = FALSE)
hnp(ajuste6.superv, halfnormal = FALSE)

### El modelo final que evaluaremos ser� el modelo Gamma doble lineal generalizado, que utiliza las 2 covariables para modelar la media y
### s�lo el log(gblancos) para modelar la dispersi�n, dando como resultado coeficientes significativos, un menor AIC 
## y seg�n el gr�fico los datos est�n dentro de la banda de confianza
### ajust�ndose en mayor proporci�n a la media de la variable de respuesta. 

### a- Prueba de hip�tesis del modelo evaluado

gamma.shape(ajuste6.superv)
# Desvio del modelo
ajuste6.superv$deviance
Dstar<-ajuste6.superv$deviance*gamma.shape(ajuste6.superv)$alpha
Dstar
ajuste6.superv$df.residual
# evaluando el ajuste
1-pchisq(q = Dstar,df =  ajuste6.superv$df.residual)

### Un p-valor mayor a 0.05, por lo cual se acepta la hip�tesis nula que indica un buen ajuste de modelo

### b - Evaluacion de residuos del modelo evaluado

# Residuo de componentes de desvio - Doble Gamma

## Con la funci�n de Polet
fit.model=ajuste6.superv
source("diag_gama_dglm.txt")

## De acuerdo la evaluaci�n de residuos se ha identificado un posible dato influyente (21), por lo cual se evaluar� si es conveniente o no el retiro de �sta observaci�n en el modelo

### c.- Diagn�stico de observaciones incluyentes del modelo evaluado

out=c(21)
res1=round(summary(ajuste6.superv)$coef,3)

fit.xtract = dglm(Tiempo ~ factor(AG) + log(gblancos), ~ log(gblancos), family=Gamma(link=log),data = data, subset = -21)
res1=cbind(res1,round(summary(fit.xtract)$coef,3),var=round(100*(coef(ajuste6.superv)-coef(fit.xtract))/coef(ajuste6.superv),2))
res1

aic_fit.xtract <- fit.xtract$m2loglik+2*5;aic_fit.xtract

fit.model=fit.xtract
source("diag_gama_dglm.txt")

par(mfrow=c(1,2))
hnp(ajuste6.superv, halfnormal = FALSE)
hnp(fit.xtract, halfnormal = FALSE)
par(mfrow=c(1,1))

# 
# par(mfrow=c(2,2))
# fit.model <- ajuste6.superv
# attach(data)
# source("envel_gama_dglm_disp.txt")
# 
# fit.model2 <- fit.temp
# attach(data)
# source("envel_gama_dglm_disp2.txt")
# par(mfrow=c(1,1))

## Podemos concluir que un mejor modelo resulta sin extraer la observaci�n 21,
## debido a que si bien �sta observaci�n genera una variaci�n porcentual de 32% en el efecto de la variable AG y una disminuci�n del AIC de 296 a 286, 
## no establece un ajuste apropiado en la media de los datos, �sto puede observarse en los gr�ficos de bondad de ajuste donde algunas observaciones salen de la bannda de confianza.


########################### Pregunta 2

data2 = as.data.frame(scan("exameOAB.dat", list(idadestado=0, idadetraco=0,
                               aemedia=0, genero=0, idade=0, oabexame=0, flagstress=0,
                               turma=0, respexame=0)))
str(data2)
data2$genero= as.factor(data2$genero)
data2$oabexame= as.factor(data2$oabexame)
data2$flagstress= as.factor(data2$flagstress)
data2$turma= as.factor(data2$turma)
data2$respexame= as.factor(data2$respexame)
str(data2)

attach(data2)
### a- An�lisis descriptivo

## tablas de contingencia

## G�nero con variable de respuesta
tab1 = with(data2,CrossTable(genero,respexame,prop.chisq=FALSE))
# 0 masculino
# 1 femenino

## Del total de hombres el 25.7% aprueba, mientras que en el grupo de mujeres el 29.7% aprueban. Por lo tanto, se observa una diferencia porcentual pero deber�a evaluarse si es significativa.

## Flag dar examen por primera vez con variable de respuesta
tab2 = with(data2,CrossTable(oabexame,respexame,prop.chisq=FALSE))
# 0 no es la primera vez que realiza el examen
# 1  es la primera vez que realiza el examen

## Del total del grupo que no da por primera vez el examen aprueban el 27.7%, mientras que en el grupo que lo da por primera vez lo aprueba el 27.9%. Por lo cual intuimos que no existe correlaci�n.
## Por otro lado, s�lo el 19.8% de los registros pertenece al grupo de no dar el examen por primera vez.

## Flag presencia de estr�s con variable de respuesta
tab3 = with(data2,CrossTable(flagstress,respexame,prop.chisq=FALSE))
# 0 no presencia de estr�s
# 1  presencia de estr�s

## Del total del grupo que no tiene presencia de estr�s aprueban el 34.8%, mientras que en el grupo que la tiene aprueba s�lo el 25.0%. Por lo cual intuimos que si existe correlaci�n.

## Salones con variable de respuesta
tab4 = with(data2,CrossTable(turma,respexame,prop.chisq=FALSE))

## En los salones 4, 5, 6 y 7 se evaluaron al 70.4% del total de candidatos, de los cuales los salones 6 y 7 son los que tienen mayor proporci�n de candidatos fueron aprobados.

## boxplot

# variable de respuesta vs Grado de ansiedad del candidato
boxplot(split(idadestado, respexame), names=c("Desaprobado","Aprobado"), ylab="Grado de ansiedad del candidato")

## No se observan diferencias entre las medianas del grado de ansiedad del candidato referente a los grupos desaprobado y aprobado.

# variable de respuesta vs Puntuaci�n del grado de ansiedad m�s constante
boxplot(split(idadetraco, respexame), names=c("Desaprobado","Aprobado"), ylab="puntuaci�n del grado de ansiedad m�s constante")

## Se observa que la mediana de la puntuaci�n del grado de ansiedad en los candidatos es mayor en el grupo de desaprobados.

# variable de respuesta vs puntuaci�n media de auto-eficacia
boxplot(split(aemedia, respexame), names=c("Desaprobado","Aprobado"), ylab="puntuaci�n media de auto-eficacia")

## No se observan diferencias entre las medianas de la puntuaci�n media de auto-eficancia referente a los grupos desaprobado y aprobado.

# variable de respuesta vs edad en a�os
boxplot(split(idade, respexame), names=c("Desaprobado","Aprobado"), ylab="edad en a�os")

## Se observa que de la mediana en edad es menor en el grupo de aprobados, con una baja dispersi�n. 

### b- Ajuste de modelo y selecci�n de variables con AIC

ajuste<-glm(respexame~.,family=binomial(link="logit"),data=data2)
fit.mod=stepAIC(ajuste)

summary(fit.mod)

AIC(fit.mod)
### c- Incluir una interaccion de primer orden a un nivel de significaci�n de 0.10

fit.mod.2= glm(respexame~ idadestado+idadetraco+idade+aemedia+
                 genero*oabexame+ genero*flagstress+ genero* turma+
                 oabexame*flagstress+ oabexame*turma+
                 flagstress*turma
               ,family=binomial(link="logit"),data=data2)
fit.mod.2=stepAIC(fit.mod.2)
summary(fit.mod.2)
AIC(fit.mod.2)

## Con un nivel de significaci�n de 0.1 el efecto de la interacci�n del g�nero con el flag de estr�s es significativo

# Prueba de F para evaluar la interacci�n
anova(fit.mod,fit.mod.2, test = "F")
## Se realiza una prueba F para evaluar el incluir la interacci�n entre las covariables genero y flag de estr�s, 
## obtenemos P-valor= 0.1805 Por lo tanto,la interacci�n no ser� incluida modelo.

### d- Realice un an�lisis de diagn�stico con el modelo seleccionado e interprete los resultados obtenidos.

# Desv�o del Modelo
Dstar<-fit.mod$deviance
Dstar
1-pchisq(q = Dstar,df =  fit.mod$df.residual)

### Un p-valor mayor a 0.05, por lo cual se acepta la hip�tesis nula que indica un buen ajuste de modelo

## Gr�fico de bondad de ajuste
fit.model <- fit.mod
source('envel_bino.txt')

## Gr�ficos de diagn�stico del modelo
fit.model <- fit.mod
source('diag_bino.txt')

## Interpretaci�n de los resultados obtenidos

exp(cbind(OR = coef(fit.mod), confint(fit.mod)))[-1,]-1

## El incremento en una unidad en la edad disminuye las posibilidades en aprobar el examen en 5.7%. IC95%[2.5% - 9.1%]
## El presentar estr�s disminuye las posibilidades en aprobar el examen en 51.3%, frente a no presentar estr�s. IC95%[7.2% - 74.4%]


########################### Pregunta 3

data3 <- read.table("insectos.txt",header=T)
attach(data3)

prop <- muert/exp
prop
plot(Conc, prop, main="Prop. obs. de insectos muertos por nivel de concentrac�n",pch=16)
Xmat <- cbind(muert, exp-muert)

### a - Estime un modelo de regresi�n binaria considerando funciones de enlace: log�stica, probit y cloglog. Utilizando el criterio de informaci�n de Akaike
### indique cu�l de los tres modelos ser�a m�s conveniente.

ajuste.logit<-glm(Xmat ~ Conc,family=binomial(link="logit"))
ajuste.probit<-glm(Xmat ~ Conc,family=binomial(link="probit"))
ajuste.cloglog<-glm(Xmat ~ Conc,family=binomial(link="cloglog"))

# ajuste.logit<-glm( x~ concen,family=binomial(link="logit"))
# ajuste.probit<-glm(x ~ concen,family=binomial(link="probit"))
# ajuste.cloglog<-glm(x ~ concen,family=binomial(link="cloglog"))

## Criterio de selecci�n de modelo: Akaike

AIC(ajuste.logit,ajuste.probit,ajuste.cloglog)

## Por medio del m�todo de selecci�n de modelo Akaike, el modelo con enlace cloglog es el que tiene mejor ajuste a los datos.

## Gr�fico de bondad de ajuste
fit.model <- ajuste.cloglog
source('envel_bino.txt')

## Por otro lado, gr�fico de bondad de ajuste corrobora lo indicado por el m�todo AIC.

### b- Utilizando el modelo seleccionado en a). Realice la prueba Hosmer- Lemeshow de bondad de ajuste y encuentre la curva ROC. Interprete.

## Creamos la data con el total de experimentos, a lo que llamaremos datos reales
x=numeric(sum(exp))
concen = numeric(sum(exp))
x[1:muert[1]] = rep(1,muert[1])
concen[1:exp[1]]=rep(Conc[1],exp[1])

for (i in 1:7){
  x[(sum(exp[1:i])+1):(sum(exp[1:i])+muert[i+1])] = rep(1,muert[i+1])
  concen[(sum(exp[1:i])+1):(sum(exp[1:i])+exp[i+1])] = rep(Conc[i+1],exp[i+1])
}
dat4=data.frame(x,concen)

# Predicciones sobre los datos reales de Concentracion
ajuste.cloglog<-glm(x ~ concen,family=binomial(link="cloglog"))
fitted.values(ajuste.cloglog)
bin = ifelse(fitted.values(ajuste.cloglog)<0.5,0,1)

# Desv�o del Modelo
Dstar<-ajuste.cloglog$deviance
Dstar
1-pchisq(q = Dstar,df =  ajuste.cloglog$df.residual)
### Un p-valor mayor a 0.05, por lo cual se acepta la hip�tesis nula que indica un buen ajuste de modelo

# Estad�stica de Hosmer-Lemeshow
hoslem.test(x, bin, g=8) #Donde p+1<g, con p=n�mero de covariables.
## Obteni�ndose un p-valor = 0.9896 mayor a 0.05, indicando que no existe evidencia de un mal ajuste por parte del modelo.

# Curva ROC
ROC(form=x~fitted(ajuste.cloglog),plot="ROC")
## El �rea bajo la curva es de 0.899, lo cual indica un buen ajuste del modelo (Especificidad=90.1% y Sensibilidad=77.6%)

## c- Estime en forma puntual y por un intervalo de confianza la dosis de insecticida  que produce un 90% de insectos 
## muertos e interprete los resultados obtenidos.

co=cbind(coef(ajuste.cloglog),confint(ajuste.cloglog))

p=0.9

b0 = co[1,]
b1 = co[2,]
b1.x = log(-log(1-p))-b0

IC.x = data.frame(b1.x[3]/b1[3],b1.x[1]/b1[1],b1.x[2]/b1[2])
colnames(IC.x) = c("2.5%","Puntual","97.5%")
rownames(IC.x) = c("Concentracion")
IC.x

### la concentraci�n que genera una porcentaje de muertes de 90% es 1.834457 y su IC95% [1.33 - 2.517]

require(MASS)
####################################################################
# Modelo Gamma                                                     #
####################################################################

#Distribuci�n gamma para MU = 1 fijo
par(mfrow=c(2,3))
curve(dgamma(x, rate=0.5, shape=0.5),from=0, to=5)
curve(dgamma(x, rate=1, shape=1),from=0, to=5)
curve(dgamma(x, rate=2, shape=2),from=0, to=5)
curve(dgamma(x, rate=4, shape=5),from=0, to=5)
curve(dgamma(x, rate=6, shape=6),from=0, to=5)
curve(dgamma(x, rate=8, shape=8),from=0, to=5)
par(mfrow=c(1,1))

####################################################################
# # Ejemplo 1: Turbina                                           # #
####################################################################

turbina = scan("turbina.dat", list(tipo=0, duracion=0))
attach(turbina)
tipo = factor(tipo)

# An�lisis descriptivo
plot(density(duracion))
# Boxplot
boxplot(split(duracion, tipo), ylab="Tiempo de Duraci�n")
# Estad�sticas descriptivas
turbina.m<-tapply(X=duracion,INDEX=tipo,FUN=mean)
turbina.sd<-tapply(X=duracion,INDEX=tipo,FUN=sd)
turbina.cv<-turbina.sd/turbina.m*100
desc_turb<-rbind(turbina.m,turbina.sd,turbina.cv)
row.names(desc_turb)<-c("M�dia","SD","CV")
desc_turb
# Estimaci�n usando el modelo lineal normal
ajuste4.turbina = lm(duracion ~ tipo)
#source.with.encoding('envel.norm.R', encoding='ISO-8859-1')
#source('envel.norm.txt')
source('envel.norm.txt')
envel.norm(ajuste4.turbina,iden=2)

# Estimaci�n usando el modelo Gamma
# Ignorando las turbinas
ajuste1.turbina = glm(duracion ~1, family=Gamma)
summary(ajuste1.turbina)
gamma.shape(ajuste1.turbina) #La estimaci�n confirma la asimetr�a hacia la derecha
curve(dgamma(x, rate=4.0155211/9.9766, shape=4.0155211),from=0, to=30)

# Efecto de Turbinas
ajuste2.turbina = glm(duracion ~ tipo, family=Gamma(link=identity))
summary(ajuste2.turbina)
gamma.shape(ajuste2.turbina)
# Desv�o del Modelo
Dstar<-ajuste2.turbina$deviance*gamma.shape(ajuste2.turbina)$alpha
Dstar
1-pchisq(q = Dstar,df =  ajuste2.turbina$df.residual)

# Inferencia
# Agrupando los tipos I, III y IV
# H0: B4 = B3 = 0
tipo1 = rep(c(1,2,1,1,5), 10)
tipo1 = factor(tipo1)
ajuste3.turbina = glm(duracion ~ tipo1, family=Gamma(link=identity))
summary(ajuste3.turbina)
gamma.shape(ajuste3.turbina)

# Prueba F
D0<-ajuste3.turbina$deviance
D1<-ajuste2.turbina$deviance
gl0<-ajuste3.turbina$df.residual
gl1<-ajuste2.turbina$df.residual
Fc<-((D0-D1)/(gl0-gl1))/(D1/gl1)
Fc
1-pf(q = Fc,df1 = (gl0-gl1),df2 = gl1)
anova(ajuste3.turbina,ajuste2.turbina,test = "F")

# Desv�o del Modelo
Dstar<-ajuste3.turbina$deviance*gamma.shape(ajuste3.turbina)$alpha
Dstar
1-pchisq(q = Dstar,df =  ajuste3.turbina$df.residual)

# Diagn�stico
#source.with.encoding('envel.gama.R', encoding='ISO-8859-1')
#source('envel.gama.txt')
source('http://www.poleto.com/funcoes/envel.gama.txt')
envel.gama(ajuste3.turbina)

#source.with.encoding('diag.gama.R', encoding='ISO-8859-1')
source('diag.gama.txt')
source('http://www.poleto.com/funcoes/diag.gama.txt')
diag.gama(ajuste3.turbina)
diag.gama(ajuste3.turbina,iden=c(2,2,1,0,0,1,1,0))

# Efecto de posibles observaciones influenciales
out=c(49)
res1=round(summary(ajuste3.turbina)$coef,3)

for(h in out){
  fit.temp = glm(duracion ~ tipo1, family=Gamma(link=identity),subset=-h)
  res1=cbind(res1,round(summary(fit.temp)$coef,3))
}
res1


cbind(
  coef(ajuste3.turbina),
  coef(fit.temp),
  round(100*(coef(ajuste3.turbina)-coef(fit.temp))/coef(ajuste3.turbina),2)
)

####################################################################
# # Ejemplo 2: Espinhel de Fundo                                 # #
####################################################################
# Descripci�n de los Datos:
# -------------------------
# Una muestra de n = 156 embarcaciones fue analizada durante los a�os
# 1995 a 1999 siendo 39 de la flota de Ubatuba y 117 de la flota de Santos.
# Las variables consideradas para cada embarcacion fueron:
# - frota (Santos ou Ubatuba),
# - ano (95 a 99),
# - trimestre (1 ao 4),
# - latitude (de 23,25o a 28,25o),
# - longitude(de 41,25o a 50,75o),
# - dias de pesca, captura (cantitad de pescados batata capturados, en kg),
# - cpue (captura por unidad de esfuerzo, kg/dias de pesca).
# Objetivo del Estudio 
# Explicar la cpue media seg�n las variables frota, ano, trimestre,
# latitude e longitude.
####################################################################

pesca <- read.table("pesca.dat", header=FALSE)
colnames(pesca)<-c("frota", "ano", "trimestre", "latitude", "longitude", "diaspesca", "captura","cpue")
attach(pesca)
trimestre = factor(trimestre)
ano = factor(ano)
head(pesca)


# An�lisis Exploratorio
#-----------------------

plot(density(cpue),ylab="Densidade")
boxplot(split(cpue, frota))
boxplot(split(cpue, ano))
boxplot(split(cpue, trimestre))

par(mfrow=c(1,2))
boxplot(split(latitude, frota))
boxplot(split(longitude, frota))
par(mfrow=c(1,1))


require(robustbase)
# Ver Hubert, M. and Vandervieren, E. (2008)
help(adjbox)

adjbox(split(cpue, frota))
adjbox(split(cpue, ano))

par(mfrow=c(1,2))
adjbox(split(latitude, frota))
adjbox(split(longitude, frota))

par(mfrow=c(1,1))
adjbox(split(cpue, trimestre))

library(psych)
# Santos
Sa_a�o <- describeBy(cpue[frota == "Santos"],ano[frota == "Santos"]) 
Sa_media <- round(c(Sa_a�o$`1995`$mean,Sa_a�o$`1996`$mean,Sa_a�o$`1997`$mean,Sa_a�o$`1998`$mean,Sa_a�o$`1999`$mean),2)
Sa_de <- round(c(Sa_a�o$`1995`$sd,Sa_a�o$`1996`$sd,Sa_a�o$`1997`$sd,Sa_a�o$`1998`$sd,Sa_a�o$`1999`$sd),2)
Sa_cv <- round((Sa_de/abs(Sa_media))*100,2)
Res_santos <- rbind(Sa_media,Sa_de,Sa_cv)
row.names(Res_santos)<- c("Med�a", "D.E", "CV")
colnames(Res_santos) <- c("1995", "1996", "1997", "1998", "1999")
Res_santos
# Ubatuba
Ub_a�o <- describeBy(cpue[frota == "Ubatuba"],ano[frota == "Ubatuba"]) 
Ub_media <- round(c(Ub_a�o$`1995`$mean,Ub_a�o$`1996`$mean,Ub_a�o$`1997`$mean,Ub_a�o$`1998`$mean,Ub_a�o$`1999`$mean),2)
Ub_de <- round(c(Ub_a�o$`1995`$sd,Ub_a�o$`1996`$sd,Ub_a�o$`1997`$sd,Ub_a�o$`1998`$sd,Ub_a�o$`1999`$sd),2)
Ub_cv <- round((Ub_de/abs(Ub_media))*100,2)
Res_Ubatuba <- rbind(Ub_media,Ub_de,Ub_cv)
row.names(Res_Ubatuba)<- c("Med�a", "D.E", "CV")
colnames(Res_Ubatuba) <- c("1995", "1996", "1997", "1998", "1999")
Res_Ubatuba
# Conclusiones preliminares:
# - Distribuci�n asim�trica positiva de cpue para cada flota, a�o y trimestre
# - Mayor cpue para la flota de Santos en relaci�n a la flota de Ubatuba .
# - Pocas diferencias entre los niveles de los factores a�o y trimestre. 
# - La flota de Santos prefiere latitudes y longitudes mayores que la flota de Ubatuba
# - Indicios de un ligero crecimiento de cpue con latitud aunque con la longitud la tendencia no esta bien definida
# - El supuesto de CV constante parece razonable para la flota de Santos

# Dispersion de Cpue vs predictores
par(mfrow=c(1,2))
plot(latitude, cpue, pch=16, xlab="Latitude")
lines(smooth.spline(latitude, cpue, df=3))
plot(longitude, cpue, pch=16, xlab="Longitude")
lines(smooth.spline(longitude, cpue, df=3))
par(mfrow=c(1,1))

# Modelo Propuesto
#-----------------------
ajuste1.pesca = glm(cpue ~  frota +  ano + trimestre + latitude + longitude, family=Gamma(link=log))
fit.model <- ajuste1.pesca
summary(fit.model)

# Seleccion de variables
require(MASS)
stepAIC(ajuste1.pesca) 

# Eliminando el factor trimestre por el m�todo de Akaike e incluyendo el factor de interaccion
ajuste2.pesca = glm(cpue ~  frota +  ano + latitude + longitude + frota*ano, family=Gamma(link=log))
ajuste3.pesca = glm(cpue ~  frota +  ano + latitude + longitude, family=Gamma(link=log))
anova(ajuste3.pesca,ajuste2.pesca, test = "F")

# Se confirma la asimetr�a hacia la derecha
gamma.shape(ajuste2.pesca)
summary(ajuste2.pesca)
# Comentarios
# - A medida que aumenta la latitud se espera un aumento del cpue, ocurriendo lo contrario con la longitud
# - Como la interacci�n es significativa se puede afirmar que la diferencia entre las medias de la cpue de
#   las flotas no es constante a lo largo de los a�os


# Interpretar interacci�n
# Santos
x0 <- data.frame(frota="Santos",ano="1995",latitude=26,longitude=46)
x01 <- data.frame(frota="Santos",ano="1996",latitude=26,longitude=46)
x02 <- data.frame(frota="Santos",ano="1997",latitude=26,longitude=46)
x03 <- data.frame(frota="Santos",ano="1998",latitude=26,longitude=46)
x04 <- data.frame(frota="Santos",ano="1999",latitude=26,longitude=46)
s1 <- predict(ajuste2.pesca,new=x0,type="response")
s2 <- predict(ajuste2.pesca,new=x01,type="response")
s3 <- predict(ajuste2.pesca,new=x02,type="response")
s4 <- predict(ajuste2.pesca,new=x03,type="response")
s5 <- predict(ajuste2.pesca,new=x04,type="response")

# Ubatuba
x_0 <- data.frame(frota="Ubatuba",ano="1995",latitude=26,longitude=46)
x_01 <- data.frame(frota="Ubatuba",ano="1996",latitude=26,longitude=46)
x_02 <- data.frame(frota="Ubatuba",ano="1997",latitude=26,longitude=46)
x_03 <- data.frame(frota="Ubatuba",ano="1998",latitude=26,longitude=46)
x_04 <- data.frame(frota="Ubatuba",ano="1999",latitude=26,longitude=46)
u1 <- predict(ajuste2.pesca,new=x_0,type="response")
u2 <- predict(ajuste2.pesca,new=x_01,type="response")
u3 <- predict(ajuste2.pesca,new=x_02,type="response")
u4 <- predict(ajuste2.pesca,new=x_03,type="response")
u5 <- predict(ajuste2.pesca,new=x_04,type="response")

a�o <- c(1995,1996,1997,1998,1999)
Santos <- c(s1,s2,s3,s4,s5)
Ubatuba <- c(u1,u2,u3,u4,u5)
f <- cbind(Santos,Ubatuba)
matplot(a�o,f,type="l", col=c("deepskyblue4", "firebrick1"), ylab
        ="cpue estimada",xlab="A�o",lwd=2)
legend("topright",c("Santos", "Ubatuba"),
       col = c("deepskyblue4", "firebrick1"), lty=1:2,lwd=2,
       seg.len=2,cex=0.8,box.lty=0,bg=NULL)

# Diagn�stico
envel.gama(ajuste2.pesca, iden =c(4))
diag.gama(ajuste2.pesca)
diag.gama(ajuste2.pesca, iden=c(2,2,2,0,2,2,3,0))

####################################################################
# Modelo Normal Inversa                                            #
####################################################################
source('invgauss.txt')
#Distribuci�n Normal Inversa para MU = 2 fijo
par(mfrow=c(2,3))
curve(dig(x,mu = 2,lambda = 1),from=0, to=6)
curve(dig(x,mu = 2,lambda = 2),from=0, to=6)
curve(dig(x,mu = 2,lambda = 3),from=0, to=6)
curve(dig(x,mu = 2,lambda = 4),from=0, to=6)
curve(dig(x,mu = 2,lambda = 6),from=0, to=6)
curve(dig(x,mu = 2,lambda = 10),from=0, to=6)
par(mfrow=c(1,1))

####################################################################
# # Ejemplo: Snacks                                              # #
####################################################################
snack = scan("snack.dat", list(cisalhamento=0, grupo=0, semana=0))
attach(snack)
grupo = factor(grupo)
snack

# An�lisis descriptivo

fuerza.m<-tapply(X=cisalhamento,INDEX=grupo,FUN=mean)
fuerza.sd<-tapply(X=cisalhamento,INDEX=grupo,FUN=sd)
fuerza.cv<-fuerza.sd/fuerza.m*100
desc_fuerza<-rbind(fuerza.m,fuerza.sd,fuerza.cv)
row.names(desc_fuerza)<-c("M�dia","SD","CV")
desc_fuerza

boxplot(split(cisalhamento, grupo), xlab="Grupo", ylab="Cisalhamento")
boxplot(split(cisalhamento, semana), xlab="Semanas", ylab="Cisalhamento")


semfuerza.m<-tapply(X=cisalhamento,INDEX=semana,FUN=mean)
semfuerza.sd<-tapply(X=cisalhamento,INDEX=semana,FUN=sd)
semfuerza.cv<-semfuerza.sd/semfuerza.m*100
desc_semfuerza<-rbind(semfuerza.m,semfuerza.sd,semfuerza.cv)
row.names(desc_semfuerza)<-c("M�dia","SD","CV")
desc_semfuerza

# Boxplots con ajuste para distribuciones asim�tricas
require(robustbase)
adjbox(split(cisalhamento, grupo), xlab="Grupo", ylab="Cisalhamento")
adjbox(split(cisalhamento, semana), xlab="Semanas", ylab="Cisalhamento")

interaction.plot(semana,grupo,cisalhamento, fixed=TRUE,
                 xlab="Semanas",
                 ylab="Fuerza de corte")


# Estimaci�n usando el modelo Normal Inversa
s1 = semana
s2 = s1*s1
fit1.snack = glm(cisalhamento ~ grupo + s1 + s2,
                 family=inverse.gaussian(link=identity))
summary(fit1.snack)

# Estimaci�n par�metro precisi�n
length(cisalhamento)/fit1.snack$deviance

# Estimaci�n usando el modelo Gamma
s1 = semana
s2 = s1*s1
fit2.snack = glm(cisalhamento ~ grupo + s1 + s2,
                 family=Gamma(link=identity))
summary(fit2.snack)

# Comparaci�n Modelo Gamma y Normal Inversa
rs1<-rstandard(fit1.snack,type="pearson")
rs2<-rstandard(fit2.snack,type="pearson")

par(mfrow=c(1,2))
plot(fit1.snack$fitted.values,rs1,pch=19,ylim=c(-2.5,4.2),
     xlab="Valores Ajustados (Normal Inversa)",
     ylab= "Residuo de Person")
plot(fit2.snack$fitted.values,rs2,pch=19,ylim=c(-2.5,4.2),
     xlab="Valores Ajustados (Gamma)",
     ylab= "Residuo de Person")
par(mfrow=c(1,1))
# Para el modelo Gamma se observa una mayor tendencia sistem�tica creciente

# Desv�o del Modelo
gamma.shape(fit2.snack)$alpha
Dstar<-fit2.snack$deviance*gamma.shape(fit2.snack)$alpha
Dstar
1-pchisq(q = Dstar,df =  fit2.snack$df.residual)

# Diagn�stico modelo final
#source.with.encoding('diag.ig.R', encoding='ISO-8859-1')
source('invgauss.txt')
source('diag.ig.txt')
source('envel.ig2.txt')
diag.ig(fit1.snack)
envel.ig2(fit1.snack, link="identity")



####################################################################
# # Ejemplo: Seguros                                             # #
####################################################################
library(MASS)
car <- read.table("car.csv",sep=",",header=T)
#### Discretizaci�n del valor del Veh�culo 
valuecat <- cut(car$veh_value, c(-1,2.5,5.0,7.5,10.0,12.5,100))

#### Crear variables con la misma categor�a de referencia dada por
#### Jong e Heller (2008)
age.x <- C(factor(car$agecat),base=3) ## agecat=3 nivel base 
area.x <- C(factor(car$area),base=3) ## area C es 3er nivel
gender.x <- C(factor(car$gender),base=2) ## gender M es 2do nivel
veh_body.x <- C(factor(car$veh_body),base=10) ## SEDAN es 10mo nivel 

car <- cbind(car,valuecat, age.x,area.x,gender.x,veh_body.x)

## Ajuste a un modelo Gamma

# Modelo con interacci�n g�nero y edad
model1 <- glm(claimcst0 ~ age.x + gender.x + age.x*gender.x + area.x + veh_body.x,
              family=Gamma(link="log"),data=subset(car,clm==1))
summary(model1)
gamma.shape(model1)


# Desv�o del Modelo
Dstar<-model1$deviance*gamma.shape(model1)$alpha
Dstar
1-pchisq(q = Dstar,df =  model1$df.residual)


model1b <- glm(claimcst0 ~ age.x + gender.x + area.x,
               family=Gamma(link="log"),data=subset(car,clm==1))
summary(model1b)
gamma.shape(model1b)

# Desv�o del Modelo
Dstar<-model1b$deviance*gamma.shape(model1b)$alpha
Dstar
1-pchisq(q = Dstar,df =  model1b$df.residual)


## Ajuste a un modelo Normal Inversa
model2 <- glm(claimcst0 ~ age.x + gender.x + area.x,
              family=inverse.gaussian(link="log"),data=subset(car,clm==1))
summary(model2)

# Estimaci�n par�metro precisi�n
dim(subset(car,clm==1))[1]/model2$deviance




